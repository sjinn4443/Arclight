// js/dashboard.js
import { loadPage } from './navigation.js';

const wired = new WeakSet(); // guard against double-binding

export function initializeDashboard() {
  const root = document.getElementById('unifiedDashboard');
  if (!root || wired.has(root)) return;
  wired.add(root);

  // 1) Greeting
  const username = (localStorage.getItem('username') || '').trim();
  const helloEl  = root.querySelector('.hello');
  if (helloEl) helloEl.textContent = `Hello ${username || 'there'}!`;

  // 2) ☰ menu → menu overlay/page
  const menuBtn = root.querySelector('.menuBtn');
  if (menuBtn) {
    menuBtn.addEventListener('click', (e) => {
      e.preventDefault();
      loadPage('menu');
    }, { once: true }); // run once; navigation swaps DOM anyway
  }

  // 3) Category cards
  // inside initializeDashboard()
const routeMap = {
  eyesModules:  'eyes', 
  earsModules:  'ears',
  skinModules:  'videos',
  teachModules: 'videos',
  eyesCatalogPage: 'eyes',
  earsLearningModules: 'ears'
};

root.querySelectorAll('.category-card').forEach((btn) => {
  btn.addEventListener('click', () => {
    const direct = btn.getAttribute('data-route');
    const key    = btn.getAttribute('data-target');
    const route  = direct || routeMap[key] || key || 'videos';
    loadPage(route);
  }, { once: true });
});


  // 4) Atoms Card quick action
  // 5) Download Contents quick action
  root.querySelectorAll('.quick-actions .pill').forEach((pill) => {
    const label = pill.textContent.trim().toLowerCase();
    if (label.includes('atoms')) {
      pill.addEventListener('click', () => loadPage('atomscard'), { once: true });
    } else if (label.includes('download')) {
      pill.addEventListener('click', () => loadPage('offline'), { once: true });
    }
  });

  // 6) Recommended for you (simple random)
  const recHost = document.getElementById('recommendedPlaceholder');
  if (recHost) renderRecommendations(recHost);
}

/* helpers */
/* helpers */
function shuffle(a) {
  const arr = a.slice();
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}
function escapeHTML(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

/* === Recommended modules (baseline-parity) === */
function renderRecommendations(host) {
  // same items & tags you had in baseline script.js, adapted to aftersplit routes
  const ALL = [
    { title: 'Direct Ophthalmoscopy',  route: 'videos',  tag: 'Video • Quiz' },
    { title: 'Visual Acuity',          route: 'videos',  tag: 'Video' },
    { title: 'Pupil Exam',             route: 'videos',  tag: 'Video' },
    { title: 'Cataract',               route: 'videos',  tag: 'Case Study' },
  ];

  const picks = shuffle(ALL).slice(0, 2);

  host.innerHTML = '';
  const wrap = document.createElement('div');
  wrap.style.display = 'grid';
  wrap.style.gap = '10px';

  picks.forEach(({ title, route, tag }) => {
    const card = document.createElement('button');
    card.type = 'button';
    card.style.textAlign = 'left';
    card.style.padding = '10px 12px';
    card.style.borderRadius = '12px';
    card.style.border = '1px solid #e3e3e6';
    card.style.background = '#fff';
    card.innerHTML = `
      <div style="font-weight:600;margin-bottom:4px">${escapeHTML(title)}</div>
      <div style="font-size:12px;color:#666">${escapeHTML(tag || '')}</div>
    `;
    card.addEventListener('click', () => loadPage(route));
    wrap.appendChild(card);
  });

  host.appendChild(wrap);
}




function shuffle(a) {
  const arr = a.slice();
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}
function escapeHTML(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
